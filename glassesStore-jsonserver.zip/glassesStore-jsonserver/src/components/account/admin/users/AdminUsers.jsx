import React from 'react';
import { Link } from 'react-router-dom';
import TitleSearch from '../../../sectionTitle/search/TitleSearch';
import UserItem from '../../../userCard/UserCard';
import styles from './AdminUsers.module.css';
import removeSVG from '../../../../assets/admin/person_remove.svg';

const data = [
    {
        nome: 'Andreas Nikolaus Lauda',
        email: 'niki.lauda@usp.br',
        id: 12543565
    },
    {
        nome: 'Ayrton Senna da Silva',
        email: 'senna@usp.br',
        id: 12523112
    },
    {
        nome: 'Nelson Piquet Souto Maior',
        email: 'piquet@usp.br',
        id: 13513112
    },
    {
        nome: 'Emerson Fittipaldi',
        email: 'fittipaldi@usp.br',
        id: 99513112
    }
]

const AdminUsers = () => {
    const [query, setQuery] = React.useState('');
    const [users, setUsers] = React.useState(data);

    const handleRemoveUser = (id) => {
        // Filter out the user with the given id
        const updatedUsers = users.filter((user) => user.id !== id);
        setUsers(updatedUsers);
    };
      
    return (
        <section>
            <TitleSearch
                title={'Usuários'}
                label={'id ou nome do usuário'}
                id='query'
                type={'text'}
                value={query}
                setValue={setQuery}
                classname='mb-40'
            />
        
        <ul className={styles.users}>
        {users.map((user) => (
          <li className={styles.user} key={user.id}>
            <UserItem data={user} />

            <div className={styles.buttons}>
              <Link to={`${user.id}`} className={styles.details}>
                detalhes
              </Link>
            </div>

            <div>
            <Link to={'#'} className={styles.remove}  onClick={() => handleRemoveUser(user.id)}>
                <p>REMOVER</p>
                <img src={removeSVG} alt="Remove" />
            </Link>

            </div>
          </li>
        ))}
      </ul>
        </section>
    );
}

export default AdminUsers;
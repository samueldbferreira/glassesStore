import React from 'react';

import styles from './Home.module.css';


const Home = () => {
  return (
    <section>
      <h1>Home</h1>
    </section>
  )
}

export default Home;
